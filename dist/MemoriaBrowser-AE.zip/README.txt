MEMORIA BROWSER FOR AFTER EFFECTS

Files
  MemoriaBrowser.jsx
  MemoriaData.jsxinc

Keep both files together.

INSTALL AS A DOCKABLE PANEL
1. Copy both files into After Effects' "Scripts/ScriptUI Panels" folder.
2. Restart After Effects.
3. Open Window > Memoria Browser.

RUN WITHOUT INSTALLING
1. Keep both files together in any folder.
2. In After Effects, choose File > Scripts > Run Script File.
3. Select MemoriaBrowser.jsx.

USE
1. Choose Japanese, English (Translated), or English (Official).
2. Click Random Memoria as often as you like. This only changes the preview.
3. Select/open a composition.
4. Click Create Text Layer when you want to add the displayed description.

Created text is left-aligned inside a centered paragraph box. Its width and
height can be entered as composition percentages in the panel; the defaults are
66% width and 33% height. Font size is calculated to fit each entry and scales
with the composition resolution.

The panel is offline and contains the wiki data captured on 2026-08-13.
Text source: Magia Record English Wiki contributors, CC BY-SA.
Source list: https://magireco.fandom.com/wiki/Memoria_List
